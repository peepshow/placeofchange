<header class="banner" role="banner">
    <div id="logo" class="wrapper"> 
        <svg width="38px" height="40px" viewBox="0 0 38 40" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
            <title>logo</title>   
            <g id="logo">
                <path fill="#505050" d="M18.9108462,10.8844444 L37.8221795,0 L18.9108462,39.5061728 L0,0 L18.9108462,10.8844444"></path>
            </g>
        </svg>
        <div class="fallback"></div>
        <h1>Starterr</h1>
        <p><em>a PressRoom boilerplate theme & content</em></p>
    </div>
</header>